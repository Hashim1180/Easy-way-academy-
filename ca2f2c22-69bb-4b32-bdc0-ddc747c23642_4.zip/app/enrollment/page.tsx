'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useState } from 'react';

export default function EnrollmentPage() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    age: '',
    course: '',
    experience: '',
    goals: '',
    schedule: '',
    startDate: ''
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Validate required fields
    if (!formData.firstName || !formData.lastName || !formData.email || !formData.course) {
      setSubmitStatus('Please fill in all required fields.');
      setIsSubmitting(false);
      return;
    }

    try {
      const formBody = new URLSearchParams();
      Object.entries(formData).forEach(([key, value]) => {
        formBody.append(key, value);
      });

      const response = await fetch('https://readdy.ai/api/form-submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formBody.toString()
      });

      if (response.ok) {
        setSubmitStatus('Enrollment successful! We will contact you within 24 hours.');
        setFormData({
          firstName: '',
          lastName: '',
          email: '',
          phone: '',
          age: '',
          course: '',
          experience: '',
          goals: '',
          schedule: '',
          startDate: ''
        });
      } else {
        setSubmitStatus('Submission failed. Please try again.');
      }
    } catch (error) {
      setSubmitStatus('Network error. Please check your connection and try again.');
    }
    
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-80 flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.6), rgba(0, 0, 0, 0.6)), url('https://readdy.ai/api/search-image?query=Happy%20students%20filling%20enrollment%20forms%20for%20German%20language%20course%2C%20diverse%20group%20of%20people%20registering%20for%20language%20academy%20with%20friendly%20staff%20helping%20them%2C%20modern%20registration%20office%20with%20German%20educational%20materials%20and%20welcoming%20atmosphere&width=1920&height=640&seq=enrollment-hero&orientation=landscape')`
        }}
      >
        <div className="text-center text-white max-w-4xl mx-auto px-6">
          <h1 className="text-5xl font-bold mb-6">Enroll Today</h1>
          <p className="text-xl">
            Start your German learning journey with Deutsche Akademie
          </p>
        </div>
      </section>

      {/* Enrollment Form */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <div className="bg-white rounded-xl shadow-lg p-8">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold text-gray-900 mb-4">Course Enrollment Form</h2>
              <p className="text-gray-600">Fill out the form below to enroll in your chosen German course</p>
            </div>

            <form id="enrollment-form" onSubmit={handleSubmit} className="space-y-8">
              {/* Personal Information */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Personal Information</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      placeholder="Enter your first name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      placeholder="Enter your last name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      placeholder="your.email@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      placeholder="+49 123 456 7890"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Age
                    </label>
                    <input
                      type="number"
                      name="age"
                      value={formData.age}
                      onChange={handleChange}
                      min="16"
                      max="80"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                      placeholder="25"
                    />
                  </div>
                </div>
              </div>

              {/* Course Selection */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Course Selection</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Choose Your Course *
                    </label>
                    <div className="relative">
                      <select
                        name="course"
                        value={formData.course}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm appearance-none bg-white"
                      >
                        <option value="">Select a course level</option>
                        <option value="A1 - Beginner">A1 - Beginner (€299)</option>
                        <option value="A2 - Elementary">A2 - Elementary (€349)</option>
                        <option value="B1 - Intermediate">B1 - Intermediate (€399)</option>
                        <option value="B2 - Upper-Intermediate">B2 - Upper-Intermediate (€449)</option>
                        <option value="C1 - Advanced">C1 - Advanced (€499)</option>
                        <option value="C2 - Proficiency">C2 - Proficiency (€549)</option>
                        <option value="Business German">Business German (€699)</option>
                        <option value="Exam Preparation">Exam Preparation (€599)</option>
                      </select>
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center">
                        <i className="ri-arrow-down-s-line text-gray-400"></i>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Preferred Schedule
                    </label>
                    <div className="relative">
                      <select
                        name="schedule"
                        value={formData.schedule}
                        onChange={handleChange}
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm appearance-none bg-white"
                      >
                        <option value="">Select preferred schedule</option>
                        <option value="Morning (9:00-12:00)">Morning (9:00-12:00)</option>
                        <option value="Afternoon (14:00-17:00)">Afternoon (14:00-17:00)</option>
                        <option value="Evening (18:00-21:00)">Evening (18:00-21:00)</option>
                        <option value="Weekend">Weekend</option>
                        <option value="Flexible">Flexible</option>
                      </select>
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center">
                        <i className="ri-arrow-down-s-line text-gray-400"></i>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Preferred Start Date
                    </label>
                    <input
                      type="date"
                      name="startDate"
                      value={formData.startDate}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      German Experience Level
                    </label>
                    <div className="relative">
                      <select
                        name="experience"
                        value={formData.experience}
                        onChange={handleChange}
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm appearance-none bg-white"
                      >
                        <option value="">Select your experience</option>
                        <option value="Complete Beginner">Complete Beginner</option>
                        <option value="Some Basic Knowledge">Some Basic Knowledge</option>
                        <option value="Intermediate">Intermediate</option>
                        <option value="Advanced">Advanced</option>
                        <option value="Native Speaker">Native Speaker</option>
                      </select>
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 w-4 h-4 flex items-center justify-center">
                        <i className="ri-arrow-down-s-line text-gray-400"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Learning Goals */}
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Learning Goals</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Why do you want to learn German? What are your goals?
                  </label>
                  <textarea
                    name="goals"
                    value={formData.goals}
                    onChange={handleChange}
                    rows={4}
                    maxLength={500}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-sm resize-none"
                    placeholder="Tell us about your motivation and goals for learning German (max 500 characters)"
                  ></textarea>
                  <div className="text-right text-sm text-gray-500 mt-1">
                    {formData.goals.length}/500 characters
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="text-center pt-6">
                {submitStatus && (
                  <div className={`mb-6 p-4 rounded-lg ${
                    submitStatus.includes('successful') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                  }`}>
                    {submitStatus}
                  </div>
                )}
                
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-blue-600 text-white px-12 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? 'Submitting...' : 'Submit Enrollment'}
                </button>
                
                <p className="text-sm text-gray-600 mt-4">
                  By submitting this form, you agree to our terms and conditions. We will contact you within 24 hours to confirm your enrollment.
                </p>
              </div>
            </form>
          </div>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">Need Help with Enrollment?</h2>
          <p className="text-xl text-blue-100 mb-8">
            Our admissions team is here to help you choose the right course
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-phone-line text-blue-600 text-xl"></i>
              </div>
              <div className="font-semibold">Call Us</div>
              <div className="text-blue-100">+49 30 123 4567</div>
            </div>
            <div>
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-mail-line text-blue-600 text-xl"></i>
              </div>
              <div className="font-semibold">Email Us</div>
              <div className="text-blue-100">admissions@deutscheakademie.com</div>
            </div>
            <div>
              <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-map-pin-line text-blue-600 text-xl"></i>
              </div>
              <div className="font-semibold">Visit Us</div>
              <div className="text-blue-100">123 Education Street, Berlin</div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}