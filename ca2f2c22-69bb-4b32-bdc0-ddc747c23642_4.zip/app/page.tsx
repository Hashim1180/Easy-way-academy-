
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section 
        className="relative h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.4)), url('https://readdy.ai/api/search-image?query=Modern%20language%20learning%20classroom%20with%20German%20flags%20and%20books%2C%20students%20studying%20German%20language%20in%20bright%20clean%20academic%20environment%20with%20blackboard%20showing%20German%20text%2C%20professional%20educational%20setting%20with%20warm%20lighting%20and%20contemporary%20furniture&width=1920&height=1080&seq=hero-german-academy&orientation=landscape')`
        }}
      >
        <div className="w-full max-w-7xl mx-auto px-6 lg:px-8 text-center text-white">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Master German Language
            <br />
            <span className="text-blue-400">The Easy Way</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto leading-relaxed">
            Join thousands of students who have successfully learned German at The Easy Way Academy. 
            From beginner to advanced levels, we provide comprehensive courses tailored to your needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/courses" className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
              Explore Courses
            </Link>
            <Link href="/enrollment" className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-gray-900 transition-colors cursor-pointer whitespace-nowrap">
              Enroll Today
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Why Choose The Easy Way Academy?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              We provide the most effective and engaging German language education with proven teaching methods
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-user-star-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Expert Instructors</h3>
              <p className="text-gray-600">
                Learn from native German speakers and certified language instructors with years of teaching experience
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-calendar-check-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Flexible Schedule</h3>
              <p className="text-gray-600">
                Choose from morning, evening, or weekend classes. Online and in-person options available
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-100 text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <i className="ri-award-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Certified Programs</h3>
              <p className="text-gray-600">
                Prepare for official German language certifications including Goethe, TestDaF, and telc exams
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Course Levels Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Course Levels</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              From complete beginner to advanced proficiency, we have the right course for your level
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[ 
              { level: 'A1 - Beginner', description: 'Start your German journey with basic vocabulary and grammar', icon: 'ri-seedling-line', color: 'bg-green-500' },
              { level: 'A2 - Elementary', description: 'Build confidence with everyday conversations and situations', icon: 'ri-plant-line', color: 'bg-blue-500' },
              { level: 'B1 - Intermediate', description: 'Express yourself on familiar topics and handle travel situations', icon: 'ri-tree-line', color: 'bg-yellow-500' },
              { level: 'B2 - Upper-Intermediate', description: 'Discuss complex topics and understand detailed texts', icon: 'ri-mountain-line', color: 'bg-orange-500' },
              { level: 'C1 - Advanced', description: 'Express ideas fluently and understand implicit meanings', icon: 'ri-rocket-line', color: 'bg-purple-500' },
              { level: 'C2 - Proficiency', description: 'Master German with native-like understanding and expression', icon: 'ri-medal-line', color: 'bg-red-500' }
            ].map((course, index) => (
              <div key={index} className="bg-gray-50 p-6 rounded-xl border border-gray-200 hover:shadow-lg transition-shadow">
                <div className={`w-12 h-12 ${course.color} rounded-lg flex items-center justify-center mb-4`}>
                  <i className={`${course.icon} text-white text-xl`}></i>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{course.level}</h3>
                <p className="text-gray-600 mb-4">{course.description}</p>
                <Link href="/courses" className="text-blue-600 font-medium hover:text-blue-700 transition-colors cursor-pointer whitespace-nowrap">
                  Learn More →
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Statistics Section */}
      <section className="py-20 bg-blue-600 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">5000+</div>
              <div className="text-blue-200">Happy Students</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">98%</div>
              <div className="text-blue-200">Success Rate</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">15+</div>
              <div className="text-blue-200">Years Experience</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">50+</div>
              <div className="text-blue-200">Expert Teachers</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-4">Ready to Start Learning German?</h2>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Join our community of learners and take the first step towards mastering the German language
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/enrollment" className="bg-blue-600 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap">
              Enroll Now
            </Link>
            <Link href="/contact" className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-gray-900 transition-colors cursor-pointer whitespace-nowrap">
              Contact Us
            </Link>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
