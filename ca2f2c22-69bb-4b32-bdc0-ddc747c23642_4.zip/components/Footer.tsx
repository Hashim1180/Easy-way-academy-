
'use client';

import Link from 'next/link';

export default function Footer() {
  return (
    <footer className="bg-gray-50 border-t border-gray-200">
      <div className="max-w-7xl mx-auto px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <i className="ri-graduation-cap-line text-white text-lg"></i>
              </div>
              <span className="text-xl font-bold text-gray-900" style={{ fontFamily: 'var(--font-pacifico)' }}>
                The Easy Way Academy
              </span>
            </div>
            <p className="text-gray-600 mb-4 max-w-md">
              Your premier destination for learning German the easy way. We offer comprehensive courses for all levels, 
              from beginners to advanced speakers.
            </p>
            <div className="flex space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                <i className="ri-facebook-fill text-white"></i>
              </div>
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                <i className="ri-twitter-fill text-white"></i>
              </div>
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                <i className="ri-instagram-line text-white"></i>
              </div>
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center cursor-pointer hover:bg-blue-700 transition-colors">
                <i className="ri-youtube-fill text-white"></i>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Quick Links</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/courses" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                  Our Courses
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/admission" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                  Admission Process
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-600 hover:text-blue-600 transition-colors cursor-pointer">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-4">Contact Info</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <i className="ri-map-pin-line text-blue-600 mt-1"></i>
                <span className="text-gray-600">123 Education Street, Berlin, Germany</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="ri-phone-line text-blue-600"></i>
                <span className="text-gray-600">+49 30 123 4567</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="ri-mail-line text-blue-600"></i>
                <span className="text-gray-600">info@deutscheakademie.com</span>
              </li>
              <li className="flex items-center space-x-2">
                <i className="ri-time-line text-blue-600"></i>
                <span className="text-gray-600">Mon-Fri: 9:00-18:00</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-200 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-600 text-sm">
            © 2024 The Easy Way Academy. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="#" className="text-gray-600 hover:text-blue-600 text-sm transition-colors cursor-pointer">
              Privacy Policy
            </Link>
            <Link href="#" className="text-gray-600 hover:text-blue-600 text-sm transition-colors cursor-pointer">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
